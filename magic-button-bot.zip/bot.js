const TelegramBot = require('node-telegram-bot-api');

const token = '7785980490:AAGQu7l-syqQU4stRQXeVsYSNTvwdWlBw5A';
const bot = new TelegramBot(token, { polling: true });

// Временни данни (в реален случай - база)
const users = {};

function getUser(id) {
  if (!users[id]) {
    users[id] = {
      wallet: 10,
      balance: 0,
      pressCount: 0
    };
  }
  return users[id];
}

function getStatusText(user) {
  return `🎮 Welcome to the Bonus Game!\n` +
         `Every 3rd press: +1$\nEvery 6th press: +3$\nEvery 9th press: +5$\nResets after 9 presses.\n\n` +
         `📊 Status:\n` +
         `💼 Wallet: ${user.wallet} $\n` +
         `💰 Balance: ${user.balance} $\n` +
         `🔢 Last Press Number: ${user.pressCount}`;
}

function getGameKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🔘 PRESS BUTTON', callback_data: 'press' }]
      ]
    }
  };
}

bot.onText(/\/start/, (msg) => {
  const user = getUser(msg.from.id);
  bot.sendMessage(msg.chat.id, getStatusText(user), getGameKeyboard());
});

bot.on('callback_query', (query) => {
  const userId = query.from.id;
  const user = getUser(userId);

  if (user.wallet <= 0) {
    bot.answerCallbackQuery(query.id, { text: '❌ Not enough funds in wallet!' });
    return;
  }

  user.wallet -= 1;
  user.pressCount += 1;

  let reward = 0;
  if (user.pressCount === 3) reward = 1;
  else if (user.pressCount === 6) reward = 3;
  else if (user.pressCount === 9) {
    reward = 5;
    user.pressCount = 0;
  }

  user.balance += reward;
  user.wallet += reward;

  bot.editMessageText(
    getStatusText(user),
    {
      chat_id: query.message.chat.id,
      message_id: query.message.message_id,
      ...getGameKeyboard()
    }
  );

  bot.answerCallbackQuery(query.id, { text: reward > 0 ? `🎉 Bonus: +${reward}$!` : '✅ Button pressed!' });
});
