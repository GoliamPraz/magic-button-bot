# Magic Button Bot
Telegram бот с бонус точки и Web3 автоматично теглене.

## Стартиране локално
1. Създай `.env` файл с нужните ключове (виж `.env пример`)
2. `npm install`
3. `npm start`

## Деплой в Railway
- Качи този проект в GitHub
- В Railway: "New Project" → "Deploy from GitHub"
- Задай `TELEGRAM_TOKEN`, `PRIVATE_KEY`, `RPC_URL` в Variables
- Railway ще стартира автоматично
